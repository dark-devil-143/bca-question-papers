document.getElementById('submitForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const message = document.getElementById('formMessage');
  message.textContent = 'Thank you! Your paper has been submitted.';
  message.style.color = 'green';
  this.reset(); // clear form
});